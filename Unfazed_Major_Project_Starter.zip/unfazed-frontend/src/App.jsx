import { useState } from 'react';
import { Routes, Route, Link, useNavigate, useParams } from 'react-router-dom';
import api from './api';

function Auth({ mode }) {
  const [form, setForm] = useState({ name: '', email: '', password: '' });
  const [error, setError] = useState('');
  const nav = useNavigate();
  async function submit(e) {
    e.preventDefault(); setError('');
    try {
      const { data } = await api.post(`/auth/${mode}`, form);
      localStorage.setItem('unfazed_token', data.token);
      localStorage.setItem('unfazed_therapist', JSON.stringify(data.therapist));
      nav('/dashboard');
    } catch (err) { setError(err.response?.data?.message || 'Unable to continue. Check the API and your details.'); }
  }
  return <main className="auth"><section className="card"><p className="eyebrow">UNFAZED · PRACTICE MANAGEMENT</p><h1>{mode === 'register' ? 'Create your practice' : 'Welcome back'}</h1><p className="muted">A calmer way to manage your therapy practice.</p><form onSubmit={submit}>
    {mode === 'register' && <input placeholder="Your name" required value={form.name} onChange={e=>setForm({...form,name:e.target.value})}/>}
    <input type="email" placeholder="Email address" required value={form.email} onChange={e=>setForm({...form,email:e.target.value})}/>
    <input type="password" placeholder="Password (8+ characters)" minLength="8" required value={form.password} onChange={e=>setForm({...form,password:e.target.value})}/>
    <button>{mode === 'register' ? 'Create account' : 'Sign in'}</button></form>{error && <p className="error">{error}</p>}
    <p className="muted">{mode === 'register' ? 'Already registered?' : 'New to Unfazed?'} <Link to={mode === 'register' ? '/login' : '/register'}>{mode === 'register' ? 'Sign in' : 'Create account'}</Link></p></section></main>;
}
function Dashboard() {
  const therapist = JSON.parse(localStorage.getItem('unfazed_therapist') || '{}');
  const nav = useNavigate();
  function logout(){localStorage.clear();nav('/login');}
  return <div className="shell"><header><Link className="brand" to="/">unfazed<span>.</span></Link><button className="outline" onClick={logout}>Log out</button></header><main><p className="eyebrow">THERAPIST WORKSPACE</p><h1>Hello, {therapist.name || 'Therapist'}.</h1><p className="muted">Your practice, in one place.</p><div className="grid">
    {['Appointments','Clients & intake','Payments & invoices','Clinical notes','Messages','Analytics'].map((x,i)=><article className="tile" key={x}><div className="tile-icon">{['◷','♡','₹','✎','☏','↗'][i]}</div><h3>{x}</h3><p className="muted">Module scaffold — ready for the next development sprint.</p></article>)}
  </div><article className="profile"><h2>Your public profile</h2><p>Share this link with clients:</p><code>{location.origin}/p/{therapist.slug || 'your-slug'}</code></article></main></div>;
}
function PublicProfile(){const {slug}=useParams();const [profile,setProfile]=useState(null);const [error,setError]=useState('');useState(()=>{api.get(`/therapists/public/${slug}`).then(r=>setProfile(r.data.therapist)).catch(()=>setError('Profile not found'));},[]);return <main className="auth"><section className="card">{profile?<><p className="eyebrow">THERAPIST PROFILE</p><h1>{profile.name}</h1><p>{profile.bio || 'Welcome. More information coming soon.'}</p><p className="muted">{(profile.specializations||[]).join(' · ')}</p></>:<p>{error||'Loading profile…'}</p>}<Link to="/">Unfazed</Link></section></main>}
export default function App(){return <Routes><Route path="/" element={<div className="landing"><nav><Link className="brand" to="/">unfazed<span>.</span></Link><div><Link to="/login">Sign in</Link><Link className="navbutton" to="/register">Get started</Link></div></nav><section className="hero"><p className="eyebrow">YOUR PRACTICE. ONE LINK.</p><h1>More time for<br/><em>what matters.</em></h1><p>Thoughtful tools for independent therapists to manage clients, sessions and their practice.</p><Link className="cta" to="/register">Create your practice →</Link></section><footer>UNFAZED · PRACTICE MANAGEMENT</footer></div>}/><Route path="/login" element={<Auth mode="login"/>}/><Route path="/register" element={<Auth mode="register"/>}/><Route path="/dashboard" element={<Dashboard/>}/><Route path="/p/:slug" element={<PublicProfile/>}/></Routes>}
