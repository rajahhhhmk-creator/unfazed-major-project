import dotenv from 'dotenv';
dotenv.config();
import http from 'http';
import app from './src/app.js';
import { Server } from 'socket.io';
import connectDB from './src/config/db.js';

const server = http.createServer(app);
const io = new Server(server, { cors: { origin: process.env.CLIENT_URL || 'http://localhost:5173' } });
io.on('connection', socket => {
  socket.on('join-room', room => socket.join(String(room)));
  socket.on('chat-message', ({ room, message }) => {
    if (room && message) io.to(String(room)).emit('chat-message', { message, sentAt: new Date() });
  });
});

const PORT = process.env.PORT || 5000;
connectDB().then(() => server.listen(PORT, () => console.log(`Unfazed API running on ${PORT}`)));
