import mongoose from 'mongoose';
const therapistSchema = new mongoose.Schema({
  name: { type: String, required: true, trim: true },
  email: { type: String, required: true, unique: true, lowercase: true, trim: true },
  passwordHash: { type: String, required: true, select: false },
  slug: { type: String, required: true, unique: true, lowercase: true },
  bio: { type: String, default: '' },
  specializations: [{ type: String }],
  languages: [{ type: String }],
  subscriptionTier: { type: String, default: 'free' }
}, { timestamps: true });
export default mongoose.model('Therapist', therapistSchema);
