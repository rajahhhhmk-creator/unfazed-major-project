Planned models from the brief: Client, Session, SessionNote, Availability, Payment,
Package, ClientPackage, Lead, SubscriptionTierConfig. Add schemas here as each
module is implemented. Keep clinical note visibility enforced server-side.
