import jwt from 'jsonwebtoken';
import Therapist from '../models/Therapist.js';
export async function protect(req, res, next) {
  try {
    const token = req.headers.authorization?.startsWith('Bearer ')
      ? req.headers.authorization.split(' ')[1] : null;
    if (!token) return res.status(401).json({ message: 'Authentication required' });
    const payload = jwt.verify(token, process.env.JWT_SECRET);
    req.therapist = await Therapist.findById(payload.id);
    if (!req.therapist) return res.status(401).json({ message: 'Account not found' });
    next();
  } catch {
    return res.status(401).json({ message: 'Invalid or expired token' });
  }
}
