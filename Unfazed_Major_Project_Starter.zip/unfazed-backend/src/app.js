import express from 'express';
import cors from 'cors';
import authRoutes from './routes/authRoutes.js';
import therapistRoutes from './routes/therapistRoutes.js';
import { errorHandler } from './middleware/errorHandler.js';

const app = express();
app.use(cors({ origin: process.env.CLIENT_URL || 'http://localhost:5173' }));
app.use(express.json());
app.get('/api/health', (_req, res) => res.json({ status: 'ok', app: 'Unfazed API' }));
app.use('/api/auth', authRoutes);
app.use('/api/therapists', therapistRoutes);
app.use('/api/scheduling', (_req,res) => res.status(501).json({ message: 'Scheduling module scaffolded; implementation pending.' }));
app.use('/api/clients', (_req,res) => res.status(501).json({ message: 'CRM module scaffolded; implementation pending.' }));
app.use('/api/payments', (_req,res) => res.status(501).json({ message: 'Payments module scaffolded; implementation pending.' }));
app.use('/api/notes', (_req,res) => res.status(501).json({ message: 'Clinical notes module scaffolded; implementation pending.' }));
app.use('/api/analytics', (_req,res) => res.status(501).json({ message: 'Analytics module scaffolded; implementation pending.' }));
app.use(errorHandler);
export default app;
