import { Router } from 'express';
import { protect } from '../middleware/authMiddleware.js';
import { myProfile, updateProfile, publicProfile } from '../controllers/therapistController.js';
const router = Router();
router.get('/public/:slug', publicProfile);
router.get('/me', protect, myProfile);
router.patch('/me', protect, updateProfile);
export default router;
