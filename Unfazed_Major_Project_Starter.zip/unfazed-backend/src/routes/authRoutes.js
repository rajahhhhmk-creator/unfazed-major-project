import { Router } from 'express';
import { body } from 'express-validator';
import { register, login } from '../controllers/authController.js';
const router = Router();
router.post('/register', [body('name').trim().notEmpty(), body('email').isEmail().normalizeEmail(), body('password').isLength({ min: 8 })], register);
router.post('/login', [body('email').isEmail()], login);
export default router;
