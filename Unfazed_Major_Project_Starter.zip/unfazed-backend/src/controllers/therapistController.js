import Therapist from '../models/Therapist.js';
export async function myProfile(req, res) {
  res.json({ therapist: req.therapist });
}
export async function updateProfile(req, res, next) {
  try {
    const allowed = ['name', 'bio', 'specializations', 'languages'];
    for (const key of allowed) if (req.body[key] !== undefined) req.therapist[key] = req.body[key];
    await req.therapist.save();
    res.json({ therapist: req.therapist });
  } catch (e) { next(e); }
}
export async function publicProfile(req, res, next) {
  try {
    const therapist = await Therapist.findOne({ slug: req.params.slug }).select('name slug bio specializations languages');
    if (!therapist) return res.status(404).json({ message: 'Profile not found' });
    res.json({ therapist });
  } catch (e) { next(e); }
}
