import bcrypt from 'bcryptjs';
import jwt from 'jsonwebtoken';
import { validationResult } from 'express-validator';
import Therapist from '../models/Therapist.js';

const makeToken = id => jwt.sign({ id }, process.env.JWT_SECRET, { expiresIn: '7d' });
const makeSlug = value => value.toLowerCase().trim().replace(/[^a-z0-9]+/g, '-').replace(/^-|-$/g, '');

export async function register(req, res, next) {
  try {
    const errors = validationResult(req);
    if (!errors.isEmpty()) return res.status(400).json({ errors: errors.array() });
    const { name, email, password } = req.body;
    if (await Therapist.findOne({ email })) return res.status(409).json({ message: 'Email already registered' });
    let slug = makeSlug(name) || 'therapist';
    let candidate = slug, n = 1;
    while (await Therapist.findOne({ slug: candidate })) candidate = `${slug}-${++n}`;
    const passwordHash = await bcrypt.hash(password, 12);
    const therapist = await Therapist.create({ name, email, passwordHash, slug: candidate });
    res.status(201).json({ token: makeToken(therapist.id), therapist: { id: therapist.id, name, email, slug: candidate } });
  } catch (e) { next(e); }
}

export async function login(req, res, next) {
  try {
    const { email, password } = req.body;
    const therapist = await Therapist.findOne({ email: email?.toLowerCase() }).select('+passwordHash');
    if (!therapist || !(await bcrypt.compare(password || '', therapist.passwordHash)))
      return res.status(401).json({ message: 'Invalid email or password' });
    res.json({ token: makeToken(therapist.id), therapist: { id: therapist.id, name: therapist.name, email: therapist.email, slug: therapist.slug } });
  } catch (e) { next(e); }
}
