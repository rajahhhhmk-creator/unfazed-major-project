// Centralized feature access. Move tier limits/flags into MongoDB config before production.
const DEFAULT_TIERS = {
  free: { features: ['profile', 'basic_booking'], caps: { activeClients: 10 } },
  pro: { features: ['profile', 'basic_booking', 'chat', 'templates', 'analytics'], caps: { activeClients: 1000 } }
};
export function canAccess(tier, featureKey) {
  const config = DEFAULT_TIERS[tier] || DEFAULT_TIERS.free;
  return config.features.includes(featureKey);
}
export function getTierConfig(tier) { return DEFAULT_TIERS[tier] || DEFAULT_TIERS.free; }
