Service boundaries to implement: schedulingService (atomic slot booking),
paymentService (Razorpay orders/signature/webhooks), notificationService,
invoiceService, leadDistributionService and analytics aggregation service.
